# Prerequisites

- Participant teams should have an Azure subscription with:

  - A service principal

    - Creating a Service Principal: [doc](https://learn.microsoft.com/en-us/azure/developer/terraform/authenticate-to-azure?tabs=bash#create-a-service-principal)
      - This describes how to create a service principal using the Azure CLI. You can also create a service principal using the Azure Portal.
    - NOTE: Copy the Service Principal's `Application ID (Client ID)` and the `Client Secret Value`
    - Here are some other useful links related to Service Principals:

      - [Application and service principal objects](https://learn.microsoft.com/en-us/entra/identity-platform/app-objects-and-service-principals?tabs=browser)
      - [Securing service principals](https://learn.microsoft.com/en-us/entra/architecture/service-accounts-principal)

    - Contributor access for all users at the Subscription level
    - At the subscription level, Azure Container Registry "Pull Image" permission 'AcrPull' needs to be granted. This can be done with the [Role Based Access Control Administrator role](https://learn.microsoft.com/en-us/azure/role-based-access-control/delegate-role-assignments-overview?tabs=template#role-based-access-control-administrator-role):

      - In your subscription, choose the 'Access control (IAM)' blade, and then choose the 'Role assignments' tab. Click 'Add', and then 'Add role assignent'.
      - Under 'Privileged administrator roles', choose 'Role Based Access Control Administrator (Preview)'. Click 'Next'.
        - ![RBAC Admin](/docs/images/rbacadmin.png)
      - Choose 'User, group, or service principal', and then choose the service principal you created above. Click 'Next'.
      - Leave 'Delegation type' as 'Constrained'. Choose 'Add condition'.
      - Under 'Constrain roles', choose 'Configure', and then 'Add role'.
      - From the list, search for 'AcrPull', check the box, and then choose 'Select'.
        - ![Constrain Roles](/docs/images/constrainroles.png)
      - Choose 'Save', 'Save' again, 'Review + assign', and finally 'Review + assign' again.
      - Read more about Container Registry roles and permissions [here](https://learn.microsoft.com/en-us/azure/container-registry/container-registry-roles?tabs=azure-cli)

    - A handful of [resource providers](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-providers-and-types) will need to be enabled in your Azure Subscription to deploy the services in this solution:

      - `Microsoft.ContainerRegistry`
      - `Microsoft.Sql`
      - `Microsoft.Maps`
      - `Microsoft.Web`
      - `Microsoft.KeyVault`
      - `Microsoft.Insights`

    - To enable these resource providers, you may either register the above in the [Azure Portal](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-providers-and-types#azure-portal) or run the following commands using the [Azure CLI](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-providers-and-types#azure-cli):

      ```
      az provider register --namespace microsoft.containerregistry
      az provider register --namespace microsoft.sql
      az provider register --namespace microsoft.maps
      az provider register --namespace microsoft.web
      az provider register --namespace microsoft.keyvault
      az provider register --namespace microsoft.insights
      ```

  - A storage account for Terraform
    - Create a `Resource Group` for the Storage Account [[guide](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/manage-resource-groups-portal#create-resource-groups)]
    - Create a `Storage Account` [[guide](https://learn.microsoft.com/en-us/azure/storage/common/storage-account-create?tabs=azure-portal)]
    - Note the `Resource Group Name`, the `Storage Account Name`, and the `Region`

- The proctor of the workshop should create a new GitHub Enterprise Organization, and the code in this repository should be imported as the base repository in that Enterprise Organization. Participants should be given access to the new organization, and in Lab-00, they will fork this repository to their own repository stored in the newly created Enterprise Organization.
- All participants should be invited to this newly created Enterprise Organization, and should have Write access within the Organization, and Read access to the base repository.

### Setup

1.  Create a GitHub App. This app will be used to write the secrets and variables to the repo in [5-TF-Setup-Repo](.github/workflows/5-TF-Setup-Repo.yml)
    1. Navigate to the GitHub Org `Settings`
    1. Navigate to `Developer Settings` -> `GitHub Apps`
    1. Click `New GitHub App`
    1. Name the app (e.g., Repo Writer)
    1. Input a description (e.g., A Repo Writing App)
    1. Enter a Homepage URL (e.g., https://www.microsoft.com)
    1. Uncheck `Expire user authorization tokens`
    1. Uncheck `Active` under `Webhook`
    1. Add the following `Repository Permissions`
       - Environments - Read and Write
       - Metadata - Read only (will be added automatically)
       - Secrets - Read and Write
       - Variables - Read and Write
    1. Choose `Only on this account`
    1. Click `Create GitHub App`
    1. In the Registration Successful message, click on `generate a private key`. Generate and download the private key.
    1. Save the `App ID`
    1. Click on `Install App`
    1. Choose `All Repositories`
    1. After the install, copy the `installation id`. This is the last portion of the url. The url will be `https://github.com/organizations/<org>/settings/installations/<installation id>`
1.  Add GitHub Org Level Secrets
    1. Navigate to the GitHub Org `Settings`
    1. Navigate to `Secrets and Variables` -> `Actions`
1.  Add the following `Secrets`
    ```
    AZURE_CLIENT_ID = <SERVICE PRINCIPAL CLIENT ID>
    AZURE_CLIENT_SECRET = <SERVICE PRINCIPAL CLIENT SECRET>
    AZURE_SUBSCRIPTION_ID = <SUBSCRIPTION ID>
    AZURE_TENANT_ID = <TENANT ID>
    REPO_ENVIRONMENT_WRITER_ID = <GitHub App's App ID>
    REPO_ENVIRONMENT_WRITER_INSTALLATION_ID = <GitHub App Installation ID>
    REPO_ENVIRONMENT_WRITER_PEM = <Contents of the Private Key File>
    ```
1.  Add the following `Variables`
    ```
    TF_REGION = <Region of the Storage Account created above>
    TF_RESOURCE_GROUP = <Name of the resource group created above>
    TF_STORAGE_ACCOUNT= <Name of the Storage Account created above>
    ```

### Pre-reading

Prior to the workshop, participants should have an understanding of content in following materials:

- [What is DevOps?](https://learn.microsoft.com/en-us/devops/what-is-devops)
- [What is Infrastructure as Code (IaC)?](https://learn.microsoft.com/en-us/devops/deliver/what-is-infrastructure-as-code)
- [What is Terraform?](https://developer.hashicorp.com/terraform/intro)
- [What is a Landing Zone?](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/landing-zone/)
