-- Populating tbl_DimRoom based on existing offices

-- For Microsoft - Las Colinas (OfficeID=1)
INSERT INTO tbl_DimRoom
    (OfficeID, RoomName)
VALUES
    (1, 'Las Colinas Conference Room A'),
    (1, 'Las Colinas Meeting Room 101'),
    (1, 'Las Colinas Auditorium'),
    (1, 'Las Colinas Break Room'),
    (1, 'Las Colinas Executive Lounge');

-- For Microsoft - Redmond (OfficeID=2)
INSERT INTO tbl_DimRoom
    (OfficeID, RoomName)
VALUES
    (2, 'Redmond Conference Room A'),
    (2, 'Redmond Meeting Room 101'),
    (2, 'Redmond Auditorium'),
    (2, 'Redmond Break Room'),
    (2, 'Redmond Executive Lounge');

-- For Microsoft - Chicago (OfficeID=3)
INSERT INTO tbl_DimRoom
    (OfficeID, RoomName)
VALUES
    (3, 'Chicago Conference Room A'),
    (3, 'Chicago Meeting Room 101'),
    (3, 'Chicago Auditorium'),
    (3, 'Chicago Break Room'),
    (3, 'Chicago Executive Lounge');
