-- Insert 10 realistic events into tbl_FactEvent

INSERT INTO tbl_FactEvent
    (RoomID, EventName, EventOwner, EventStartDateTime, EventEndDateTime)
VALUES
    (1, 'Product Launch Meeting', 'Jennifer Smith', '2023-10-01 09:00:00', '2023-10-01 11:00:00'),
    (2, 'Team Offsite Discussion', 'Brian Johnson', '2023-10-02 10:00:00', '2023-10-02 15:00:00'),
    (3, 'Financial Review', 'Charles Brown', '2023-10-03 13:00:00', '2023-10-03 15:00:00'),
    (4, 'HR Policy Refresh', 'Natalie Davis', '2023-10-04 15:00:00', '2023-10-04 17:00:00'),
    (5, 'Quarterly Sales Review', 'Erica Martinez', '2023-10-05 16:00:00', '2023-10-05 18:00:00'),
    (6, 'Engineering Sprint Retrospective', 'Derek Clark', '2023-10-06 09:00:00', '2023-10-06 10:30:00'),
    (7, 'Design Thinking Workshop', 'Angela Robinson', '2023-10-07 11:00:00', '2023-10-07 15:00:00'),
    (8, 'Customer Feedback Session', 'Oliver Wilson', '2023-10-08 14:00:00', '2023-10-08 16:30:00'),
    (9, 'Marketing Strategy Planning', 'Isabella Taylor', '2023-10-09 09:00:00', '2023-10-09 12:30:00'),
    (10, 'Leadership Training', 'Sophia Lee', '2023-10-10 12:00:00', '2023-10-10 15:00:00');
