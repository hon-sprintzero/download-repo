-- Populating tbl_DimOffice based on provided JSON
INSERT INTO tbl_DimOffice
    (OfficeName, OfficeAddress, OfficeCity, OfficeState, OfficeZip, OfficeCountry)
VALUES
    ('Microsoft - Las Colinas', '7100 State Hwy 161', 'Irving', 'TX', '75039', 'USA'),
    ('Microsoft - Redmond', 'Microsoft Building 92, NE 36th St', 'Redmond', 'WA', '98052', 'USA'),
    ('Microsoft - Chicago', '200 E Randolph St #200', 'Chicago', 'IL', '60601', 'USA');
