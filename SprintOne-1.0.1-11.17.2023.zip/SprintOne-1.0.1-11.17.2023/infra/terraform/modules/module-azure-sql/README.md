After provisioning SQL infrastructure, follow the below prior to running a CI/CD pipeline to publish the database schema to the newly created database.

Need to allow Azure services - this is not currently supported by Terraform, so it needs to be done manually.
https://github.com/hashicorp/terraform-provider-azurerm/issues/8714