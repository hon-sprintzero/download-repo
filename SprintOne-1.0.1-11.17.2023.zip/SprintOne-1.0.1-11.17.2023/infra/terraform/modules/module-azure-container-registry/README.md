# module-acr
Terraform module to provision a [Container Registry](<https://docs.microsoft.com/en-us/azure/container-registry/>).

## Usage

```HCL
module "acr" {
  source                   = "../terraform_modules/acr"
  name                     = "demo-acr-weu"
  resource_group_name      = "demo-rg-weu"
  location                 = "westeurope"
  sku                      = "Basic"
  admin_enabled            = false
  tags                     = {
    environment = "demo"
    tenant      = "t0001"
    solution    = "paa"
    alteration  = "1"
    location    = "westeurope"
  }
}


resource "azurerm_container_registry" "acr" {
  name                     = var.acr_name
  resource_group_name      = var.resource_group_name
  location                 = var.location
  sku                      = var.sku_name
  admin_enabled            = false
  tags                     = var.tags
}

```

## Module Details

This module creates an Azure Container Registry to build, store, and manage images for all types of container deployments


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| acr\_name | The name of the Container Registry | string | n/a | yes |
| admin\_enabled | Specifies whether the admin user is enabled. Defaults to false | string | `"false"` | no |
| location | Specifies the supported Azure location where the resource exists | string | n/a | yes |
| resource\_group\_name | The name of the resource group in which to create the Container Registry | string | n/a | yes |
| sku\_name | The SKU name of the the container registry. Possible values are Classic (which was previously Basic), Basic, Standard and Premium | string | `"Basic"` | no |
| tags | A mapping of tags to assign to resource group | map | `<map>` | no |

## Outputs

| Name | Description |
|------|-------------|
| admin\_password | The Password associated with the Container Registry Admin account - if the admin account is enabled. |
| admin\_username | The Username associated with the Container Registry Admin account - if the admin account is enabled. |
| id | The Container Registry ID |
| login\_server | The URL that can be used to log into the container registry.. |
## Changelog

### v 1.0.0 2019-07-05

* Initial version