# End-to-End DevOps Workshop

## Introduction

This lab-based workshop is designed to tackle the the core challenges of building a repeatable DevOps platform. This codebase focuses on the aspects most pertinent to building an automated, scalable, and multi-technology full-stack solution using industry best practices focused on tooling available from Microsoft. This codebase is for demonstration purposes only. As an outcome of this workshop, you will have a working solution that you can use as a reference/starting point for your own projects.

## Learning Objectives

This solution will help you learn:

1. How to use GitHub to manage source control, perform CI/CD, and manage projects
2. How to use Terraform to codify and provision infrastructure in Azure
3. How to use Azure App Service to host a scalable Containerized Go Application, ASP.NET Application, and React Application
4. How to leverage common design patterns to build an application for enterprise scale

## Labs

- Lab 00: **[Setup](labs/Lab-00.md)**
  - Set up repository and local environment
- Lab 01: **[Provision Infrastructure](labs/Lab-01.md)**
  - Deploy infrastructure via Terraform
- Lab 02: **[Run Applications](labs/Lab-02.md)**
  - Run sample app locally
- Lab 03: **[Modify the codebase](labs/Lab-03.md)**
  - Modify the sample app to trigger a build
- Lab 04: **[Run CI/CD Pipelines](labs/Lab-04.md)**
  - Automate CI/CD pipelines and code promotion
- Lab 05: **[Autoscaling](labs/Lab-05.md)**
  - Enable autoscaling for the API via Terraform
- Lab 06: **[Enabling SAST Scanning](labs/Lab-06.md)**
  - Enable security scanning via CI/CD pipeline

## Prerequisites

A link to a guide describing all prerequisites and the steps to complete them can be found [here](docs/Prerequisites.md).

## How this solution differs from a Production-ready solution

- Pipelines that deploy Terraform scripts are broken into multiple files for ease of understanding. These pipelines are initialized by a "workflow_dispatch" event, which allows you to manually trigger the pipeline from the GitHub UI. In a production-ready solution, these pipelines would be triggered by a commit to the main branch.
- Networking is not configured in this codebase for simplicity. For example, in a production-ready solution, networking would be configured to allow access to the application from the internet, and to allow access to the database from the application.

## Diagrams

![Solution Architecture](/docs/images/solutionarchitecture.png)

## Contributors

- [Brian Cheng](https://github.com/bcheng-ms)
- [Ryan Pfalz](https://github.com/ryanpfalz)
- [Lyle Luppes](https://github.com/lluppesms)
