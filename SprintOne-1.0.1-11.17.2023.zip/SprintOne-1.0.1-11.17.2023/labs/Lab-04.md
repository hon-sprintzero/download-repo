# Lab 4: Run CI/CD Pipelines

[< Previous Lab](./Lab-03.md) - **[Home](../README.md)** - [Next Lab >](./Lab-05.md)

## Introduction

This lab will deploy the application components modified in Lab-03 to the infrastructure provisioned in Lab-01. The pull request created in Lab-03 will be completed, and the concepts of pull requests triggers, automated pipelines, and approval gates will be covered.

## Description

### 1. Complete the Pull Request

- To complete the pull request, navigate to the pull request in GitHub and click the 'Merge pull request' button. This will merge the pull request into the main branch. You may delete the `dev` branch after the pull request is merged.
- Navigate to the Actions tab. You will see that the merge to main triggered the following pipelines to run:
  - `CICD-React-App-Deploy`
  - `CICD-SQL-Server-Deploy`
  - `CICD-Dotnet-API-Deploy`
  - `CICD-Go-Docker-Deploy`

### 2. Hydrate the Dev Database

- Once the Dev stages (specifically the ASPNET API and SQL Database) have been deployed, to hydrate the database, simply visit `https://<your-resource-group-name>-dotnet-api-dev.azurewebsites.net/api/SampleData/Create` in your browser. This will create sample data in the Dev database.

### 3. Verify the Dev Release

- Navigate to the Azure Portal and open the App Service in the Dev Resource Group for the React Application. Upon visiting the URL, you will see React application render in the browser with the title you provided in Lab-03.

### 4. Approve the Releases to QA

- Return to the Actions tab
- In the Actions tab, once again click on each of the workflows listed in Step 1 above. You will see a yellow clock icon, indicating that the QA stage is ready to be approved for release.
- For each of the workflows, click on the stage with the message 'QA waiting for review'. Click on the 'Review pending deployments' link. In the popup, check the box for the QA environment, and then click 'Approve and deploy'.
- Perform the above step for the QA environment for each of the workflows.

### 5. Hydrate the QA Database

- Once the QA stages (specifically the ASPNET API and SQL Database) have been deployed, to hydrate the database, simply visit `https://<your-resource-group-name>-dotnet-api-qa.azurewebsites.net/api/SampleData/Create` in your browser. This will create sample data in the QA database.

### 6. Verify the QA Release

- Navigate to the Azure Portal and open the App Service in the QA Resource Group for the React Application. Upon visiting the URL, you will see React application render in the browser with the title you provided in Lab-03.

## Success Criteria

1. The React application is accessible at the URL of both the Dev and QA App Service deployed in Lab-01 with the title given in your code change
2. The Go API is accessible at the URL of both the Dev and QA App Service deployed in Lab-01 with the message given in your code change
3. The ASP.NET Core API is accessible at the URL of both the Dev and QA App Service deployed in Lab-01 with the header given in your code change
4. The SQL Server database is accessible at the URL of both the Dev and QA SQL Server deployed in Lab-01

## How these steps may differ from an Enterprise scenario

- In the lab, we use universal secrets for the Service Principal and the TF storage for simplicity. In a real deployment, the Service Principals would be different per environment.
- After a pull request is created, it would be thoroughly reviewed by a peer before being approved for merge into the main branch.
- Approval into higher environments would typically be restricted to the users who are responsible for that environment. For example, a QA team member would be responsible for approving promotion into the QA environment.
- **Did you know?** GitHub environments allow you to store secrets per environment (QA, Dev)

## Learning Resources

- [Approving a pull request](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/reviewing-changes-in-pull-requests/approving-a-pull-request-with-required-reviews)
- [Using Environments for Deployment](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment)
