# Lab 5: Autoscaling

[< Previous Lab](./Lab-04.md) - **[Home](../README.md)** - [Next Lab >](./Lab-06.md)

## Introduction

This lab will introduce the concept of autoscaling as applied to PaaS services (namely App Service) within Azure, managed entirely through Terraform. Once configured, the autoscaling profile will cause the App Service Plan to automatically scale up and down based on CPU - a common scaling metric. This lab will be heavily self-guided.

## Description

- Create and pull a new branch from the main branch called `lab-05`.
- Open the file `infra/terraform/modules/module-azure-app-service-windows/main.tf` and scroll down to the section with the comment `TODO - Autoscale (Lab-05)`. This is where the autoscaling profile will be configured.
- Referring to the [documentation for the Terraform `azurerm_monitor_autoscale_setting`](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_autoscale_setting.html) and any other resources you may find helpful, configure the autoscaling profile to the following specifications:
  Capacity:

  - The default capacity should be 1 instance
  - The minimum capacity should be 1 instance
  - The maximum capacity should be 3 instances

  Scale Up Rule:

  - Time grain sampled every minute
  - CPU Average greater than 80% over a window of 5 minutes will result in an increase of 1 instance
  - Cooldown time after scale activity of 1 minute

  Scale Down Rule:

  - Time grain sampled every minute
  - CPU Average less than 80% over a window of 5 minutes will result in a decrease of 1 instance
  - Cooldown time after scale activity of 1 minute

- Once you have completed the above, create and complete a pull request, and run `3-TF-Dotnet-API-Deploy` to apply the changes to the App Service Plan to Dev & QA.

- Navigate to the Azure Portal and open the App Service Plan in the Dev Resource Group for the ASPNET API. Click on the 'Scale out (App Service Plan)' link in the left navigation.

## Success Criteria

1. The ASPNET API App Service will see that be configured to autoscale based on CPU.

## How these steps may differ from an Enterprise scenario

- Enterprises have a variety of scaling needs; for example, a more sophisticated scaling profile may be required to handle a sudden influx of traffic. In this case, the autoscaling profile may be configured to scale up more aggressively, and scale down more conservatively. Depending on the application's traffic patterns, some businesses may choose to configure a schedule that aligns to expected traffic, where scale is higher during business hours and lower during off hours.
- Other autoscale settings like [Automatic Scaling](https://learn.microsoft.com/en-us/azure/app-service/manage-automatic-scaling?tabs=azure-portal) do not use scale rules, but instead use intelligent traffic-based metrics to determine the best scale settings for your application.
- **Did you know?** App Services also have high availability features where the app is spread across Availability Zones and across regions.

## Learning Resources

- [Autoscale Overview](https://learn.microsoft.com/en-us/azure/azure-monitor/autoscale/autoscale-overview)
- [Example REST API Settings for Autoscale](https://learn.microsoft.com/en-us/rest/api/monitor/autoscale-settings/create-or-update?tabs=HTTP#create-or-update-an-autoscale-setting)
- [ARM Examples](https://learn.microsoft.com/en-us/azure/azure-monitor/autoscale/autoscale-understanding-settings)
- [Autoscale Settings](https://learn.microsoft.com/en-us/azure/azure-monitor/reference/supported-metrics/microsoft-insights-autoscalesettings-metrics)
- [App Service Reliability](https://learn.microsoft.com/en-us/azure/reliability/reliability-app-service?tabs=graph%2Ccli#availability-zone-support)
