# Lab 6: Enabling SAST & DAST Scanning

[< Previous Lab](./Lab-05.md) - **[Home](../README.md)**

## Introduction

This lab will introduce the concept of SAST and DAST scanning as applied to a component of the application stack, executed as part of a CI/CD pipeline. Automated testing for software vulnerabilities early in the development lifecycle is critical for maintaining a secure codebase. This lab will be heavily self-guided.

## Description

- Create and pull a new branch from the main branch called `lab-06`.
- Open the file `.github/workflows/template-frontend-deploy.yml` and scroll down to the section with the comment `TODO - SAST & DAST Testing (Lab-06)`. This is where the SAST & DAST scanning will be configured.
- Using the SAST & DAST tools of your choice, add action(s) to the code to perform SAST & DAST scanning on the React application code.
  - Open Source:
    - For SAST, you may consider using the open source [Dependency-Check_Action](https://github.com/dependency-check/Dependency-Check_Action) action.
    - For DAST, you may consider using the open source [action-baseline](https://github.com/zaproxy/action-baseline) action.
  - Commercial:
    - You may also use a commercially licensed SAST & DAST tool of your choice, like the [Veracode](https://github.com/marketplace/actions/veracode-upload-and-scan) action.
- Once you have completed the above, create and complete a pull request, and run `CICD-React-App-Deploy` to execute the code scanning actions as a part of your CI/CD pipeline.

## Success Criteria

1. Security scanning actions are executed as a part of the CI/CD pipeline for the React application.

## How these steps may differ from an Enterprise scenario

- In an enterprise scenario, the SAST & DAST tools may be centrally managed by a security team, and the results would be centrally reported on. The security team would also be responsible for ensuring that the tools are kept up to date with the latest vulnerability definitions.
- Security scanning would be performed on all components of the application stack, not just the React application.
- **Did you know?** OWASP publishes the Top Ten vulnerabilities to watch out for. The DAST tooling (Zap) we use in the sample is published by OWASP. In addition, GitHub Advanced Security has tooling for SAST

## Learning Resources

- [DevSecOps with GitHub Security](https://learn.microsoft.com/en-us/azure/architecture/solution-ideas/articles/devsecops-in-github)
- [Secure at every step](https://github.blog/2020-08-13-secure-at-every-step-a-guide-to-devsecops-shifting-left-and-gitops/)
- [GitHub Advanced Security](https://docs.github.com/en/get-started/learning-about-github/about-github-advanced-security)
- [OWASP Top Ten](https://owasp.org/www-project-top-ten/)
