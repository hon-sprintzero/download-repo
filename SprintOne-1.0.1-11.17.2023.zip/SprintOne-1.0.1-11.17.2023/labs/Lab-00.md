# Lab 0: Setup

**[Home](../README.md)** - [Next Lab >](./Lab-01.md)

## Introduction

This lab will walk you through the steps to setup your environment for the rest of the labs.

_Note that this guide assumes you are using a Windows machine._

## Description

### 1. Team-level setup

- [Azure Storage will be used for storing Terraform state](https://learn.microsoft.com/en-us/azure/developer/terraform/store-state-in-azure-storage?tabs=azure-cli). A single member of your team should create a common resource group, and then create a storage account within it for storing Terraform state files ([doc](https://docs.microsoft.com/en-us/azure/storage/common/storage-account-create?tabs=azure-portal)).

- Create the following secrets at the organization level

  - `AZURE_SUBSCRIPTION_ID` - Subscription ID
  - `AZURE_TENANT_ID` - Tenant ID
  - `AZURE_CLIENT_ID` - Client ID
  - `AZURE_CLIENT_SECRET` - Client Secret

### 2. Individual-level setup

- After the team Storage Account is created, each team member should create a container in the Storage Account for storing their Terraform state files ([doc](https://docs.microsoft.com/en-us/azure/storage/blobs/storage-quickstart-blobs-portal#create-a-container)).
- Fork the repository from the base repository into your own repository within the Enterprise Organization dedicated to this workshop. Name the repository using the naming convention `<base repository name>-<your GitHub ID>`.
- Create a Dev environment and a QA environment in your repository ([doc](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment))
- Create the following secret at the environment level (in both the Dev and QA environments)

  - `SQL_ADMIN_PASSWORD` - Password you want to use for the SQL Server. NOTE: The password complexity requirements can be found [here](https://learn.microsoft.com/en-us/sql/relational-databases/security/password-policy?view=sql-server-ver16#password-complexity). Please note that 3 consecutive characters from the username are not allowed.

- Create the following variables in your repository at the environment level (in both the Dev and QA environments)

  - `TF_CONTAINER_NAME` - Name of the container you created in the Storage Account. This value should be all lower case with no spaces or special characters.
  - `SQL_ADMIN_USER` - Username you want to use for the SQL Server. This value cannot be 'admin', and should be all lower case with no spaces or special characters.
  - `SQL_INITIAL_CATALOG` - Name of the SQL Database you want to create on the server.

- In the 'Environments' settings, click the 'QA' environment. Under 'Deployment protection rules', check the box for 'Required reviewers' and add your GitHub username.
- Install Docker Desktop on your local machine ([doc](https://docs.docker.com/desktop/))
- Install NPM [doc](https://docs.npmjs.com/downloading-and-installing-node-js-and-npm)
- Install Az CLI [doc](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli)

  Where applicable, this guide provides information on executing steps via both Visual Studio and via command line.

- Visual Studio can be installed [here](https://visualstudio.microsoft.com/downloads/)
- If not using Visual Studio, you will need to install NuGet [doc](https://learn.microsoft.com/en-us/nuget/install-nuget-client-tools)
- If not using Visual Studio, you will need to install MSBuild [doc](https://learn.microsoft.com/en-us/visualstudio/msbuild/walkthrough-using-msbuild?view=vs-2022#install-msbuild)

## Success Criteria

1. You have a forked repository with a Dev and QA environment
2. A common Storage Account has been set up with a container for each team member
3. The above secrets and variables have been created in your repository
4. You have installed all prerequisite tools on your local machine

## How these steps may differ from an Enterprise scenario

- Typically, the repository would be created by an administrator, and the secrets and variables would be created by a DevOps engineer. The team members would then be given access to the repository and the secrets/variables.
- Each team member would usually be collaborating together on a single codebase. In this case, each team member will be working on their own codebase.
- **Did you know?** There are a variety of IDE extensions provided by Microsoft to help with programming efficiency and security.

## Learning Resources

- [Store Terraform state in Azure Storage](https://learn.microsoft.com/en-us/azure/developer/terraform/store-state-in-azure-storage?tabs=azure-cli)
- [Create a Resource Group](https://docs.microsoft.com/en-us/azure/azure-resource-manager/management/manage-resource-groups-portal#create-resource-groups)
- [GitHub Repo Environment Secrets](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment#environment-secrets)
- [Create a Storage Account](https://docs.microsoft.com/en-us/azure/storage/common/storage-account-create?tabs=azure-portal)
- [Create a Storage Account Container](https://learn.microsoft.com/en-us/azure/storage/blobs/blob-containers-portal)
- [GitHub Copilot](https://docs.github.com/en/copilot/github-copilot-chat/using-github-copilot-chat)
