# Lab 2: Run Applications (Optional)

[< Previous Lab](./Lab-01.md) - **[Home](../README.md)** - [Next Lab >](./Lab-03.md)

## Introduction

This lab will get you up and running with the different components of the solution and how they fit together - from communication of the components between each other to the infrastructure and automated pipelines.

This lab is optional - running these components locally are not a requirement to getting them running in Azure, but it is recommended that you run the applications locally to get a better understanding of how they work.

_Note that this guide assumes you are using a Windows machine._

## Description

### Clone your forked repository

- To start, you need to pull your forked code down to your local machine. [This document](https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository) will step you through the process of cloning your code using HTTPS, SSH, or the GitHub CLI.

### React App

- Please refer to the [React Readme](../web/Contoso.React/README.md) for detailed instructions.

### ASP.NET Core API

#### From Visual Studio

- Open the `web/Contoso.WebApi.sln` file in Visual Studio
- Open the Tools -> NuGet Package Manager -> Package Manager Console window. Click on the "Restore" button to restore the packages
- Use the 'IIS Express' profile to run the application

- Note: If you get the error `System.IO.FileNotFoundException: Could not find file '\web\Contoso.WebApi\bin\roslyn\csc.exe'` when you run the app, return to the Package Manager Console and run this command:

  ```bash
  Update-Package Microsoft.CodeDom.Providers.DotNetCompilerPlatform -r
  ```

#### From the command line

- Navigate to the root directory of the SprintOne project
- Run the following commands to build the application:

  ```bash
  nuget restore "web\Contoso.WebApi\packages.config" -PackagesDirectory "web\packages"
  msbuild.exe "web\Contoso.WebApi\Contoso.WebApi.csproj" /p:DeployOnBuild=true /p:DeployDefaultTarget=WebPublish /p:WebPublishMethod=FileSystem /p:DeleteExistingFiles=True /p:configuration="Release" /p:PublishUrl="drop"
  ```

  Note: To make the first command work, you will need to have [nuget.exe](https://learn.microsoft.com/en-us/nuget/install-nuget-client-tools) installed. To make the second command work, you will need the [Microsoft Build Tools](https://visualstudio.microsoft.com/downloads/) installed and then open the `Developer Command Prompt`, or be using a prompt that has the `msbuild.exe` in your path.

### Containerized Go API

- Navigate to the `web/Contoso.GoApi` directory
- Run the following commands to build the Docker image and start the container:

  ```bash
  docker build -t contoso-go-api .
  docker run -p 8080:8080 contoso-go-api
  ```

### SQL Database

- Open your SQL Editor of choice (e.g., Azure Data Studio) and provide the connection information for the SQL Server. The SQL password & username are the values that were configured as GitHub Secret + Variable in Lab-00; the remaining information can be found in the Azure Portal.
- You will need to whitelist your IP address in the SQL network settings to allow you to connect to the database on your local machine.
- Once a connection is established, connect to the database configured in the `SQL_INITIAL_CATALOG` variable from Lab-00.
- You may now run SQL queries against the database.

## Success Criteria

1. You are able to run the React web application locally
2. You are able to run the ASP.NET Core API locally
3. You are able to run the containerized Go API locally
4. You are able to connect to the SQL Server database locally
5. You understand which components are deployed to which cloud infrastructure resources

## How these steps may differ from an Enterprise scenario

- An organization may encourage or require the use of a standardized cloud-based development environment. This would allow developers to use a consistent environment regardless of their local machine's configuration.
- Each team may only build part of the application, relying on a shared development environment for remaining services.
- **Did you know?** GitHub Dev Containers are a great way to standardize development environments. Dev Containers can reduce setup time and standardize code styles.

## Learning Resources

- [Dev Containers](https://docs.github.com/en/codespaces/setting-up-your-project-for-codespaces/adding-a-dev-container-configuration/introduction-to-dev-containers)
