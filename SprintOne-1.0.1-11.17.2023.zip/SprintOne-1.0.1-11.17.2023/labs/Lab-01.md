# Lab 1: Provision Infrastructure

[< Previous Lab](./Lab-00.md) - **[Home](../README.md)** - [Next Lab >](./Lab-02.md)

## Introduction

This lab will use the environment you set up in the previous lab and will walk you through the steps to provision the infrastructure that you'll use for the rest of the labs.

## Description

Each of the below sections will provision the infrastructure for a different component of the solution. You will need to run each of the below sections in order to provision the infrastructure for the entire solution. Each section will save its own state file in the Storage Account you created in the previous lab.

Sections 1-5 below will each prompt you for the following parameters:

- `Environment` - Choose either Dev or QA
- `Resource Group Name` - The root name you want to name your resource group. The environment name will be appended to this value when deployed, and many of the resource names will be derived from this value. This value needs to be globally unique.
- `Location` - Location the Azure resources will be deployed into. You may find the list of available locations by running `az account list-locations`. You may keep the default value of `eastus`.
- `Short Location` - This is a tag that will be applied to the resources that are deployed. It can be set to any value, but should indicate which location you chose. You may keep the default value of `eus`.
- `Cost Center` - This is a tag that will be applied to the resources that are deployed. It can be set to any value.

All steps below need to be performed twice - once for the Dev environment and once for the QA environment.

### 1. Deploy the Common Resources

- In your repository, click on the 'Actions' tab
  - Note: Since your forked repository contains Actions workflows, you will receive a notice that workflows are disabled - this is to give you an opportunity to understand the actions and their usage before enabling them. Click the "I understand" button to enable workflows.
    ![Actions Warning](/docs/images/actionswarning.png)
- In the menu on the left under 'Actions', click on '1-TF-Common-Deploy'
- Click the 'Run workflow' dropdown, which will enable you to input the parameters described above.
- Once completed, the following resources will be created:
  - A Resource Group
  - A Container Registry
  - A Windows App Service Plan
  - A Linux App Service Plan
  - A Key Vault
  - A SQL Server
  - An Azure Maps Instance
  - An Application Insights Instance

### 2. Deploy the Resources for the React Application

- In your repository, click on the 'Actions' tab
- In the menu on the left under 'Actions', click on '2-TF-React-App-Deploy'
- Once completed, the following resources will be created:
  - An App Service for the React Application

### 3. Deploy the Resources for the ASP.NET Application

- In your repository, click on the 'Actions' tab
- In the menu on the left under 'Actions', click on '3-TF-Dotnet-API-Deploy'
- Once completed, the following resources will be created:
  - An App Service for the ASP.NET API

### 4. Deploy the Resources for the Go Application

- In your repository, click on the 'Actions' tab
- In the menu on the left under 'Actions', click on '4-TF-Go-Docker-Deploy'
- Once completed, the following resources will be created:
  - An App Service for Containers the Go Application

### 5. Finalize the setup of the Repository

- In your repository, click on the 'Actions' tab
- In the menu on the left under 'Actions', click on '5-TF-Setup-Repo'
- Once completed, the environments in your repository will be populated with all secrets and variables required for the CI/CD pipelines to run. These values are comprised of auto-generated resource names derived from the values you input in the previous steps.
- This step also hydrates the database with sample data.

### Note: Tearing down the Resources

- While the subsequent labs require the resources created in this lab, you may want to tear down the resources. To do so, follow the steps below:
  - In your repository, click on the 'Actions' tab
  - In the menu on the left under 'Actions', click on '1-TF-Common-Destroy'
  - Click the 'Run workflow' dropdown, which will enable you to input the following parameters:
    - `TF State file name` - The full path (container/statefilename.tf) of the state file from the common Storage Account that contains the resources you want to destroy.

## Success Criteria

1. All resources are provisioned in Azure through automated pipelines
2. You can view the resources created for Dev & QA in the Azure portal

## How these steps may differ from an Enterprise scenario

- Typically, the infrastructure would be provisioned by a DevOps engineer. In this case, the infrastructure is provisioned by the developers.
- This exercise is meant to illustrate creation of an entire architecture from scratch. When developing a real-world solution, you would need to use the modules to craft your own abstraction on top of them.
- This codebase splits the infrastructure into multiple pipelines for ease of understanding. The triggers for these pipelines are set to 'workflow_dispatch', which allows you to manually trigger the pipeline from the GitHub UI. In a production-ready solution, these pipelines would be triggered by a commit to the main branch.
- The terraform states have been split up to work best for this sample application. In a real-world solution, there is a design for how the scripts are managed and deployed.
- **Did you know?** Microsoft provides a Terraform based Landing Zone deployment to get started.

## Learning Resources

- [Landing Zone](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/landing-zone/deploy-landing-zones-with-terraform)
