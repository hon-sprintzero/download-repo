# Lab 3: Modify the codebase

[< Previous Lab](./Lab-02.md) - **[Home](../README.md)** - [Next Lab >](./Lab-04.md)

## Introduction

This lab will serve to emulate the "build" phase of the software development lifecycle, prompting you to modify the codebase and create a pull request, just as you would with any business requirement for a feature change. While the below actions are simple, they seek to demonstrate that changes to a codebase require an approval followed by an automated release.

## Description

### Create development branch

- In GitHub, create a new branch from the main branch called `dev`. On your local machine, fetch the changes to the repository and check the `dev` branch out.
- All below changes should be made on the `dev` branch.

### React App

- In the file `web/Contoso.React/public/index.html`, replace the "Sample App" title of the app (`<title>Sample App</title>`) with something that indicates the content of the app and your name.

### ASP.NET Core API

- In the file `web/Contoso.WebApi/Views/Home/Index.cshtml`, replace the "Contoso Room Reservations Admin App" header on the page (`<h1 id="aspnetTitle">Contoso Room Reservations Admin App</h1>`) with something that indicates the content of the app and your name.

### Containerized Go API

- In the file `web/Contoso.GoApi/main.go`, replace the "Hello, World!" message that is returned by the API (`fmt.Fprintf(w, "Hello, World!")`) with something that indicates the content of the app and your name.

### SQL Database

- Add a comment to the top of the `web/Contoso.SqlDb/dbo.tbl_DimRoom.sql` and `web/Contoso.SqlDb/dbo.tbl_FactEvent.sql` files denoting the foreign key references on the tables.
- No changes to the schema are recommended here, since the application is expecting the schema to be in the pre-defined format.

### Creating a pull request

- Finally, once all changes are complete, commit and push your changes to the `dev` branch you created.
- Open your repository in GitHub and click the 'Pull requests' tab. Click the 'New pull request' button. In the 'Compare' dropdown, select the `dev` branch as the source and the `main` branch as the target. Then, click 'Create pull request'.
- Fill out the pull request template as appropriate, provide an informative title, and then click 'Create pull request' again.
- Navigate to the Actions tab. You will see that the pull request triggered the following pipelines to run:
  - `CICD-React-App-Deploy`
  - `CICD-Dotnet-API-Deploy`
  - `CICD-Go-Docker-Deploy`
  - `CICD-SQL-Server-Deploy`

  These pipelines will deploy the components to the Dev environment.

## Success Criteria

1. A pull request is created with changes made in the `dev` branch for the React App, ASP.NET Core API, Containerized Go API, and SQL Database.
2. Pull-request-triggered pipelines run successfully.

## How these steps may differ from an Enterprise scenario

- Typically, your code changes would be more substantial and driven by business requirements.
- Tests! Tests! Tests! We have not added any tests.
- Enterprise access controls, licenses, and VPNs may be required to get your tools working properly.
- **Did you know?** GitHub provides features that help you can define and share workflows across the organization.

## Learning Resources

- [Creating a branch in your repository](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/creating-and-deleting-branches-within-your-repository)
- [Creating a pull request](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/creating-a-pull-request)
- [Sharing workflows, secrets, and runners](https://docs.github.com/en/actions/using-workflows/sharing-workflows-secrets-and-runners-with-your-organization)
