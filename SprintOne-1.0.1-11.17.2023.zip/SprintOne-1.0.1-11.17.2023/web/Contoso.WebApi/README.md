## About this component

The WebAPI component is a RESTful API that is used to expose the Contoso database to the outside world, and it includes an OpenAPI specification that describes the API for developers.

## Built with

- .NET Framework 4.8
- MVC
- Entity Framework to connect to the database

## Getting Started

### Prerequisites

- Visual Studio (any recent version)
- Azure DevOps Pipelines to build and deploy

### Installation

To build and deploy the application, run the [CICD-Dotnet-API-Deploy.yml](/.github/workflows/CICD-Dotnet-API-Deploy.ymlCICD-Dotnet-API-Deploy.yml) workflow. This workflow will build the application, save the build artifacts, and deploy the application to Azure App Service.

## Usage

The Contoso.WebApi component is the primary consumer of the database, and provides API CRUD operations for the Office, Room, and Event entities. The APIs can be viewed by going to the Swagger endpoint of the published application.

## Additional Resources

[Improve the developer experience of an API with Swagger](https://learn.microsoft.com/en-us/training/modules/improve-api-developer-experience-with-swagger/)

[Swagger](https://swagger.io/)

[OpenAPI Specification](https://swagger.io/specification/)

[Get started with Swashbuckle and ASP.NET Core](https://learn.microsoft.com/en-us/aspnet/core/tutorials/getting-started-with-swashbuckle?view=aspnetcore-7.0&tabs=visual-studio)