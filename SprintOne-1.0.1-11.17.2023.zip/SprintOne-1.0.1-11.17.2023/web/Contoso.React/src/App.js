import "./App.css";
import { Routes, Route } from "react-router-dom";
import Layout from "./pages/layout/Layout";
import GetStarted from "./pages/getstarted/GetStarted";
import Schedule from "./pages/schedule/Schedule";
import { MessageProvider } from "./util/MessageProvider";
function App() {
  return (
    <div className="App">
      <MessageProvider>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route path="/" element={<GetStarted />} />
            <Route path="/schedule/:location" element={<Schedule />} />
          </Route>
        </Routes>
      </MessageProvider>
    </div>
  );
}

export default App;
