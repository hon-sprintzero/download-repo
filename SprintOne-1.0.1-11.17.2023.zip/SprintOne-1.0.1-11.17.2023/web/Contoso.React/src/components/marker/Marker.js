import styles from "./Marker.module.css";

const Marker = ({ color }) => (
  <div className={styles.marker}>
    <div className={styles.inner} style={{ backgroundColor: color }}></div>
  </div>
);

export default Marker;
