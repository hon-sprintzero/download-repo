import React, { useState, useEffect } from "react";
import { cancelEvent, getEventsByRoom } from "../../util/api";
import styles from "./Room.module.css";
import AddEvent from "../addEvent/AddEvent";
import { IconButton, Shimmer } from "@fluentui/react";
import { useMessage } from "../../util/MessageProvider";
const Room = (props) => {
  const [showEvents, setShowEvents] = useState(false);
  const { setMessage } = useMessage();
  const [events, setEvents] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [showAddEvent, setShowAddEvent] = useState(false);
  const getEvents = async (roomId) => {
    const events = await getEventsByRoom(roomId);
    setEvents(events);
  };

  const closeAddEvent = (event) => {
    if (event && event.roomId) {
      setEvents([...events, event]);
    }
    toggleAddEvent();
  };
  const toggleEvents = async () => {
    setShowEvents(!showEvents);
  };

  useEffect(() => {
    const loadEvents = async () => {
      await getEvents(props.room.id);
      setLoaded(true);
    };
    if (!loaded) {
      loadEvents();
    }
  }, [loaded, props.room.id]);

  const toggleAddEvent = () => {
    setShowAddEvent(!showAddEvent);
  };

  const deleteEvent = (eventId) => {
    cancelEvent(eventId);
    let newEvents = events.filter((event) => event.id !== eventId);
    setEvents(newEvents);
    setMessage(`Event ${eventId} has been cancelled`);
  };

  const displayEvents = () => {
    return (
      <div className={styles.eventWrapper}>
        {events.length > 0 ? (
          events.map((event) => {
            return (
              <div key={event.id}>
                <h3>
                  {event.name}{" "}
                  <IconButton
                    iconProps={{ iconName: "Cancel" }}
                    ariaLabel="Close popup modal"
                    onClick={() => {
                      deleteEvent(event.id);
                    }}
                  />
                </h3>
                <h4>{event.owner}</h4>
                <p>{event.startDateTime}</p>
                <p>{event.endDateTime}</p>
              </div>
            );
          })
        ) : (
          <div>No events</div>
        )}
      </div>
    );
  };
  return (
    <div className={styles.roomWrapper}>
      <div className={styles.header}>
        <Shimmer isDataLoaded={loaded} ariaLabel="Loading content">
          <h3>
            <span
              onClick={async () => {
                toggleEvents();
              }}
            >
              {props.room.name} ({events.length} events){" "}
            </span>
            <span
              onClick={() => {
                toggleAddEvent();
              }}
            >
              +
            </span>
          </h3>
          <AddEvent
            isModalOpen={showAddEvent}
            toggleModal={closeAddEvent}
            roomId={props.room.id}
          />
        </Shimmer>
      </div>
      {showEvents && displayEvents()}
    </div>
  );
};

export default Room;
