import React, { useState, useEffect } from "react";
import {
  Modal,
  IconButton,
  TextField,
  DatePicker,
  DayOfWeek,
  Label,
  defaultDatePickerStrings,
  TimePicker,
  PrimaryButton,
  DefaultButton,
} from "@fluentui/react";
import { useMessage } from "../../util/MessageProvider";
import style from "./AddEvent.module.css";
import { addEventByRoom } from "../../util/api";
const AddEvent = (props) => {
  const { isModalOpen, toggleModal } = props;
  const { setMessage } = useMessage();
  const [name, setName] = useState("");
  const [owner, setOwner] = useState("");
  const [startDate, setStartDate] = useState("");
  const [startDateTime, setStartDateTime] = useState(""); // [1
  const [endDateTime, setEndDateTime] = useState(""); // 1
  const { roomId } = props; // 1
  const [disabled, setDisabled] = useState(false);
  const [validated, setValidated] = useState(false);
  const timeRange = {
    start: 8,
    end: 17,
  };
  const onStartTimeChange = React.useCallback((ev, newTime) => {
    setStartDateTime(newTime.toISOString().slice(0, 19));
  }, []);
  const onEndTimeChange = React.useCallback((ev, newTime) => {
    setEndDateTime(newTime.toISOString().slice(0, 19));
  }, []);

  const submitEvent = async () => {
    setDisabled(true);
    let id = await addEventByRoom({
      roomId,
      name,
      owner,
      startDateTime,
      endDateTime,
    });
    setMessage(`Event ${name} has been added`);
    setDisabled(false);
    toggleModal({ id, roomId, name, owner, startDateTime, endDateTime });
  };

  useEffect(() => {
    if (name && owner && startDateTime && endDateTime) {
      setValidated(true);
    }
  }, [name, owner, startDateTime, endDateTime]);
  return (
    <Modal
      titleAriaId="id"
      isOpen={isModalOpen}
      onDismiss={toggleModal}
      isBlocking={true}
      className={style.wrapper}
    >
      <div className={style.header}>
        <span className={style.title}>Add Event</span>
        <span className={style.actions}>
          <IconButton
            iconProps={{ iconName: "Cancel" }}
            ariaLabel="Close popup modal"
            onClick={toggleModal}
            className={style.closeButton}
          />
        </span>
      </div>
      <div className={style.formWrapper}>
        <TextField
          label="Name"
          onChange={(e) => {
            setName(e.target.value);
          }}
        />
        <TextField
          label="Owner"
          onChange={(e) => {
            setOwner(e.target.value);
          }}
        />
        <Label>Date</Label>
        <DatePicker
          firstDayOfWeek={DayOfWeek.Sunday}
          placeholder="Select a date..."
          ariaLabel="Select a date"
          // DatePicker uses English strings by default. For localized apps, you must override this prop.
          strings={defaultDatePickerStrings}
          onSelectDate={(date) => {
            setStartDate(date);
          }}
        />

        <TimePicker
          placeholder="Start Time"
          useHour12
          allowFreeform
          autoComplete="on"
          label="Start Time"
          timeRange={timeRange}
          onChange={onStartTimeChange}
          dateAnchor={startDate}
        />

        <TimePicker
          placeholder="End Time"
          useHour12
          allowFreeform
          autoComplete="on"
          label="End Time"
          timeRange={timeRange}
          onChange={onEndTimeChange}
          dateAnchor={startDate}
        />
        <div className={style.buttonWrapper}>
          <PrimaryButton
            text="Save"
            onClick={submitEvent}
            allowDisabledFocus
            disabled={disabled || !validated}
          />
          <DefaultButton
            text="Cancel"
            onClick={toggleModal}
            allowDisabledFocus
            disabled={disabled}
          />
        </div>
      </div>
    </Modal>
  );
};

export default AddEvent;
