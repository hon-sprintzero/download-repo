import { Outlet, Link } from "react-router-dom";
import React from "react";
import { MessageBar, MessageBarType } from "@fluentui/react";
import logo from "./logo.png";
import styles from "./Layout.module.css";
import { useMessage } from "../../util/MessageProvider";
const Layout = () => {
  const { message, setMessage } = useMessage();
  const resetMessage = () => {
    setMessage(undefined);
  };
  return (
    <div className={styles.layout}>
      <header className={styles.header} role={"banner"}>
        <div className={styles.headerContainer}>
          <Link to="/" className={styles.headerTitleContainer}>
            <img
              src={logo}
              alt="Microsoft logo"
              aria-label="Link to Home"
              height="30px"
            />
            <h4 className={styles.headerRightText}>
              Contoso Conference Reservations
            </h4>
          </Link>
          <nav>
            <ul className={styles.headerNavList}>
              <li></li>
            </ul>
          </nav>
        </div>
      </header>
      {message && (
        <MessageBar
          onDismiss={resetMessage}
          dismissButtonAriaLabel="Close"
          messageBarType={MessageBarType.success}
          isMultiline={false}
        >
          {message}
        </MessageBar>
      )}
      <Outlet />
    </div>
  );
};

export default Layout;
