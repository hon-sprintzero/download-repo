import React, { useState, useMemo, useEffect } from "react";
import {
  AzureMap,
  AzureMapsProvider,
  AzureMapHtmlMarker,
} from "react-azure-maps";
import { AuthenticationType, data } from "azure-maps-control";
import Marker from "../../components/marker/Marker";
import { useNavigate } from "react-router-dom";
import { getOffices } from "../../util/api";
import { Modal, Spinner, SpinnerSize } from "@fluentui/react";
import styles from "./GetStarted.module.css";
const option = {
  view: "Auto",
  authOptions: {
    authType: AuthenticationType.subscriptionKey,
    subscriptionKey: process.env.REACT_APP_SUBSCRIPTION_KEY,
  },
};

function azureHtmlMapMarkerOptions(marker) {
  let coordinates = data.Position(
    marker.geometry.coordinates[0],
    marker.geometry.coordinates[1]
  );
  return {
    position: coordinates,
    text: marker.properties.id,
    title: marker.properties.Name,
  };
}

function renderHTMLPoint(marker, onClick) {
  const rendId = Math.random();

  return (
    <AzureMapHtmlMarker
      key={rendId}
      markerContent={<Marker color="blue" />}
      options={{ ...azureHtmlMapMarkerOptions(marker) }}
      events={[{ eventName: "click", callback: onClick }]}
    />
  );
}

const GetStarted = () => {
  const navigate = useNavigate();

  const [htmlMarkers, setHtmlMarkers] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const memoizedHtmlMarkerRender = useMemo(
    () =>
      htmlMarkers.map((marker) => {
        return renderHTMLPoint(marker, (e) => {
          navigate(`/schedule/${e.target.options.text}`);
          //console.log("You click on: ", e.target.options.text);
        });
      }),
    [htmlMarkers, navigate]
  );

  useEffect(() => {
    // declare the async data fetching function

    const fetchData = async () => {
      // get the data from the api
      const data = await getOffices();

      data.features.forEach((marker) => {
        setHtmlMarkers((htmlMarkers) => [...htmlMarkers, marker]);
      });
      setLoaded(true);
    };

    // call the function
    if (!loaded)
      fetchData()
        // make sure to catch any error
        .catch(console.error);
  }, [htmlMarkers, loaded]);
  return (
    <div className={styles.container}>
      <div
        className={styles.flexBox}
        style={{
          paddingTop: 0,
          height: "100%",
          width: "100%",
          alignItems: "center",
          flexDirection: "column",
        }}
      >
        <div
          className={styles.flexBox}
          style={{
            paddingTop: 0,
            height: "100%",
            width: "50%",
            alignItems: "flex-start",
            flexDirection: "column",
          }}
        >
          <div style={{ height: "60vh", width: "100%" }}>
            <h2>Choose an office to view its availability:</h2>
            <AzureMapsProvider>
              <AzureMap options={option}>{memoizedHtmlMarkerRender}</AzureMap>
            </AzureMapsProvider>
          </div>
          <Modal
            titleAriaId="id"
            isOpen={!loaded}
            isBlocking={true}
            className={styles.modalBody}
          >
            <div
              className={styles.flexBox}
              style={{
                height: "60vh",
                width: "100%",
                alignItems: "center",
                flexDirection: "row",
              }}
            >
              <div
                className={styles.flexBox}
                style={{
                  height: "100%",
                  width: "100%",
                  alignItems: "center",
                  flexDirection: "column",
                }}
              >
                <Spinner size={SpinnerSize.large} />
              </div>
            </div>
          </Modal>
        </div>
      </div>
    </div>
  );
};

export default GetStarted;
