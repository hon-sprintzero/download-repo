//make a simple react function component
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getMeetingRoomsByOffice, getOfficeById } from "../../util/api";
import { Shimmer } from "@fluentui/react";
import styles from "./Schedule.module.css";
import Room from "../../components/room/Room";

const Schedule = () => {
  const { location } = useParams();
  const [rooms, setRooms] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [officeMetadata, setOfficeMetadata] = useState([]);

  useEffect(() => {
    // declare the async data fetching function

    const fetchData = async () => {
      // get the data from the api
      const data = await getOfficeById(location);
      const rooms = await getMeetingRoomsByOffice(location);
      setOfficeMetadata(data);
      setRooms(rooms);
      setLoaded(true);
    };

    // call the function
    if (!loaded)
      fetchData()
        // make sure to catch any error
        .catch(console.error);
  }, [loaded, location]);
  return (
    <div
      className={styles.flexBox}
      style={{
        paddingTop: 0,
        minHeight: "80vh",
        alignItems: "center",
        flexDirection: "row",
      }}
    >
      <div
        className={styles.flexBox}
        style={{
          paddingTop: 0,
          height: "100%",
          width: "100%",
          alignItems: "center",
          flexDirection: "column",
        }}
      >
        <h2>
          {loaded ? (
            `${rooms.length} Rooms at ${officeMetadata.name}`
          ) : (
            <Shimmer width={400} />
          )}
        </h2>
        <div
          className={styles.flexBox}
          style={{
            paddingTop: 0,
            height: "100%",
            width: "100%",
            alignItems: "center",
            flexDirection: "column",
            justifyContent: "left",
            textAlign: "center",
          }}
        >
          {rooms.map((room) => {
            return <Room room={room} key={room.id} />;
          })}
        </div>
      </div>
    </div>
  );
};

export default Schedule;
