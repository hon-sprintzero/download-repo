import { useContext, useState } from "react";
import React from "react";

export const MessageContext = React.createContext({
  message: "",
  setMessage: () => {},
});

export const MessageProvider = (props) => {
  const [message, setMessage] = useState("");

  const contextValue = {
    message,
    setMessage,
  };
  return (
    <MessageContext.Provider value={contextValue}>
      {props.children}
    </MessageContext.Provider>
  );
};

export const useMessage = () => {
  const { message, setMessage } = useContext(MessageContext);
  return { message, setMessage };
};
