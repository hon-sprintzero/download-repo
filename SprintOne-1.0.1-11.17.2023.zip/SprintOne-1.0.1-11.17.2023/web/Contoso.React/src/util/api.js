const apiGoUrl = process.env.REACT_APP_GO_API_URL;
const apiUrl = `${process.env.REACT_APP_API_URL}/api`;

const getOffices = async () => {
  const response = await fetch(`${apiGoUrl}/offices`);
  const data = await response.json();
  return data;
};

const getOfficeById = async (officeId) => {
  const response = await fetch(`${apiUrl}/office/${officeId}`);
  const data = await response.json();
  return data;
};

const getMeetingRoomsByOffice = async (officeId) => {
  const response = await fetch(`${apiUrl}/office/rooms/${officeId}`);
  const data = await response.json();
  return data;
};

const getEventsByRoom = async (roomId) => {
  const response = await fetch(`${apiUrl}/event/room/${roomId}`);
  const data = await response.json();
  return data;
};

const addEventByRoom = async (event) => {
  console.log(event);
  const response = await fetch(`${apiUrl}/event`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(event),
  });
  const data = await response.json();
  return data;
};

const cancelEvent = async (eventId) => {
  const response = await fetch(`${apiUrl}/event/${eventId}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const data = await response.json();
  return data;
};

export {
  getOffices,
  getOfficeById,
  getMeetingRoomsByOffice,
  getEventsByRoom,
  addEventByRoom,
  cancelEvent,
};
