## About this component

This component is the frontend for the application. It has 2 main pages: a map that shows the locations (data pulled from the Contoso.GoApi), and a locations details page (data pulled from the Contoso.WebApi ).

## Built with

- Node 16+
- React 18+
- Fluent UI 8+

## Getting Started

### Prerequisites

- Install Node v 16 or above [[doc](https://nodejs.org/en/download)].

- Azure Map instance (deployed in [1-TF-Common-Deploy](.github/workflows/1-TF-Common-Deploy.yml))

- Go Api instance ( deployed in [4-TF-Go-Docker-Deploy](.github/workflows/4-TF-Go-Docker-Deploy.yml) and [CICD-Go-Docker-Deploy](.github/workflows/CICD-Go-Docker-Deploy.yml))

- DotNet API instance (deployed in [3-TF-Dotnet-API-Deploy](.github/workflows/3-TF-Dotnet-API-Deploy.yml) and [CICD-Dotnet-API-Deploy](.github/workflows/CICD-Dotnet-API-Deploy.yml))

### Installation

1. Gather values for GoApi, DotNet Api, and Map instance
   - Get the DotNet Api URL. It is output in the `3-TF-Dotnet-API-Deploy` Action.
     - Navigate to the GitHub Repo -> Actions -> 3-TF-Dotnet-API-Deploy.
     - Choose a successful run
     - Scroll down to `Terraform Init, Plan, Apply summary`
     - Copy the API Url
   - Get the Go Api URL. It is output in the `4-TF-Go-Docker-Deploy` Action.
     - Navigate to the GitHub Repo -> Actions -> 4-TF-Go-Docker-Deploy.
     - Choose a successful run
     - Scroll down to `Deploy Docker Service summary`
     - Copy the API Url
   - Get the Primary Access Key from the Map Service.
     - Open the [Azure Portal](https://portal.azure.com)
     - Navigate to the Azure Map Service
     - Navigate to `Authentication`
     - Copy the `Primary Key` under `Shared Key Authentication`
1. Open a terminal
1. Navigate to `web/Contoso.React`
1. Run `npm install`
1. Create a .env file and input the values from Step 1.
   ```
   REACT_APP_SUBSCRIPTION_KEY=<MAP SERVICE PRIMARY KEY>
   REACT_APP_GO_API_URL=<GoApi URL>
   REACT_APP_API_URL=<Dotnet API URL>
   ```

## Usage

1.  Open a terminal
1.  Navigate to `web/Contoso.React`
1.  Run `npm start`

A browser will open to http://localhost:3000
