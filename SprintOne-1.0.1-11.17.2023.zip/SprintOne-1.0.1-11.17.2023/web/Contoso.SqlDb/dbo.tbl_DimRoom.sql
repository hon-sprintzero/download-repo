-- Create tbl_DimRoom with RoomID as an identity column
CREATE TABLE tbl_DimRoom
(
    RoomID INT IDENTITY(1,1) PRIMARY KEY,
    OfficeID INT,
    RoomName VARCHAR(255) NOT NULL,
    FOREIGN KEY (OfficeID) REFERENCES tbl_DimOffice(OfficeID)
);