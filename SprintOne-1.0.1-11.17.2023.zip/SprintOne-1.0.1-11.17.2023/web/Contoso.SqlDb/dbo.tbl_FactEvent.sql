-- Create tbl_FactEvent with EventID as an identity column
CREATE TABLE tbl_FactEvent
(
    EventID INT IDENTITY(1,1) PRIMARY KEY,
    RoomID INT,
    EventName VARCHAR(255) NOT NULL,
    EventOwner VARCHAR(255) NOT NULL,
    EventStartDateTime DATETIME NOT NULL,
    EventEndDateTime DATETIME NOT NULL,
    FOREIGN KEY (RoomID) REFERENCES tbl_DimRoom(RoomID)
);