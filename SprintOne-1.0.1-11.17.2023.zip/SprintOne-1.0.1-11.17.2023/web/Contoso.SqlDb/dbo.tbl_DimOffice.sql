-- Create tbl_DimOffice with OfficeID as an identity column
CREATE TABLE tbl_DimOffice
(
    OfficeID INT IDENTITY(1,1) PRIMARY KEY,
    OfficeName VARCHAR(255) NOT NULL,
    OfficeAddress VARCHAR(255) NOT NULL,
    OfficeCity VARCHAR(100) NOT NULL,
    OfficeState VARCHAR(50) NOT NULL,
    OfficeZip VARCHAR(10) NOT NULL,
    OfficeCountry VARCHAR(100) NOT NULL
);