## About this component

The SqlDb Database component is a SQL Server with a simple database containing tables representing Office, Room, and Event entities. The Office and Room tables are Dimension tables, and the Event table is a Fact table.

## Built with

- SQL
- Azure SQL Database

## Getting Started

### Prerequisites

- A SQL editor like [Azure Data Studio](https://docs.microsoft.com/en-us/sql/azure-data-studio/download-azure-data-studio?view=sql-server-ver15) or [SSMS](https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms?view=sql-server-ver15)
- An Azure SQL Database instance (deployed in [1-TF-Common-Deploy](.github/workflows/1-TF-Common-Deploy.yml))

### Installation

- To build and deploy the database schema, run the [CICD-SQL-Server-Deploy](.github/workflows/CICD-SQL-Server-Deploy.yaml) workflow after the SQL Server has been provisioned in the [1-TF-Common-Deploy](.github/workflows/1-TF-Common-Deploy.yml) step. This workflow uses `dotnet build` to build a DACPAC Artifact which is then deployed to the SQL Server using the `Azure/sql-action` GitHub Action.
- Once the database schema is deployed via the workflow, then you should proceed with running the remaining Terraform workflows to deploy the remaining infrastructure. During [5-TF-Setup-Repo](.github/workflows/5-TF-Setup-Repo.yml), the tables will automatically be populated with sample data.

## Usage

- While the database can be queried directly, the [Contoso.WebApi](/web/Contoso.WebApi) component is the primary consumer of the database, supporting CRUD operations for the Office, Room, and Event entities.

## Diagrams
![Database Diagram](/docs/images/dbschema.png)

## Additional Resources

- Within the [data/scripts](/data/scripts) directory, you will find optional scripts to populate the tables with sample data. The [PopulateSampleData.sql](/data/scripts/PopulateSampleData.sql) may be run locally to populate all tables at once with sample data.
