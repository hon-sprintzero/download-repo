## About this component

This component is a backend API that provides a list of locations, their geo-coordinates, and their metadata. It is called from `Contoso.React`. This component is self contained and serves the API using data from [offices.json](web/Contoso.GoApi/offices.json). For an example of how to connect to a database, refer to the [Contoso.WebApi](web/Contoso.WebApi/README.md) component.

## Built with

- Go 1.21.1
- Docker version 20.10.23, build 7155243

## Getting Started

### Prerequisites

- Go 1.21 and above [[install](https://go.dev/doc/install)]
- Docker Desktop [[install](https://docs.docker.com/engine/install/)]

### Installation

If you decide to only use Docker, you do not need to install Go. However, without installing Go, you will not be able to run the app without Docker.

#### Install Go Api outside of Docker

1. Open a terminal
1. Navigate to `web/Contoso.GoApi`
1. Run `go get .`
1. Run `go run main.go`
1. Open a browser and navigate to `http://localhost:8080/offices`

#### Install Go Api using Docker

1. Open a terminal
1. Navigate to `web/Contoso.GoApi`
1. Run `docker build . -t goapi:latest`

## Usage

#### Run Go Api outside of Docker

1. Open a terminal
1. Navigate to `web/Contoso.GoApi`
1. Run `go run main.go`
1. Open a browser and navigate to `http://localhost:8080/offices`

#### Run Go Api using Docker

1. Open a terminal
1. Navigate to `web/Contoso.GoApi`
1. Run `docker run -it -p 8080:8080 goapi:latest`
1. Open a browser and navigate to `http://localhost:8080/offices`
