package main

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
)

func main() {

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "Hello, World!")
	})
	http.HandleFunc("/offices", func(w http.ResponseWriter, r *http.Request) {
		fileContent, err := os.Open("offices.json")

		if err != nil {
			log.Fatal(err)
			return
		}

		fmt.Println("The File is opened successfully...")

		defer fileContent.Close()

		byteResult, _ := io.ReadAll(fileContent)

		var res map[string]interface{}
		json.Unmarshal([]byte(byteResult), &res)
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(&res)

	})
	fmt.Printf("Server running (port=8080), route: http://localhost:8080/\n")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		log.Fatal(err)
	}
}
