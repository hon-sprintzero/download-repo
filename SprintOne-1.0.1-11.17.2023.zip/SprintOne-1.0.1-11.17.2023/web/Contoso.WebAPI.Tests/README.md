## About this component

This WebAPI Test component is used to run unit tests for the Contoso.WebAPI component.  

## Built with

- MS Test framework
- The [Effort](https://entityframework-effort.net/overview) library is used to create an in-memory database for testing

## Getting Started

### Prerequisites

These tests can be run locally or in a pipeline:

- Run locally using Test Explorer in Visual Studio or Visual Studio Code
- Run during a build using Azure DevOps Pipelines tasks

### Installation

If you want to visualize the code coverage (depending on your version of Visual Studio being used), you may have to install a tool like Cobertura Coverage or Fine Code Coverage.

When this is incorporated into the Azure DevOps pipelines, you may also have to install the Azure Devops Extension
[SARIF SAST Scans Tab](https://marketplace.visualstudio.com/items?itemName=sariftools.scans) to visualize the SARIF files generated the tests.

## Usage

Use the Test Explorer in Visual Studio to run these tests manually.

At some point, these tests could also be integrated into the deployment pipeline, but that is not included in this example.

## Additional Resources

[Run unit tests with Test Explorer](https://learn.microsoft.com/en-us/visualstudio/test/run-unit-tests-with-test-explorer?view=vs-2022)

[Use code coverage for unit testing](https://learn.microsoft.com/en-us/dotnet/core/testing/unit-testing-code-coverage?tabs=windows)

[Publish code coverage task](https://learn.microsoft.com/en-us/azure/devops/pipelines/tasks/reference/publish-code-coverage-results-v2?view=azure-pipelines)